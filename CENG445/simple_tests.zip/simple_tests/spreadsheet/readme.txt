2 example csv files are given. These cover some but not all of the functions you are responsible for.
If you are exporting from different editors like MS Office, LibreOffice or GoogleSS you may see a bit different behaviour for strings and formulae. 
Also check the date and number formats.
Google export will give you values only (try show formula), LibreOffice has options for formulae in csv exports.

your libraries should be able to create ankara.csv spreadsheet with setCellValue/Formula and evaluate methods.
getCells should return the values in ankara_values.csv
we expect other methods to work on your library after this point like cut/copy/paste