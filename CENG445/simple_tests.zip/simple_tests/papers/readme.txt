Upload these papers to your library for test environment, you can add more.

search by title, author, content, getmeta etc. should work after this point.
you can complete missing parts in the given bibtex info -> setmeta(...)
notes, reminders etc. are important

For watchPaper-ID, you can use different version of the paper 4 from the link below
https://arxiv.org/abs/1409.0473
Also any metadata update should notify watchers
watchPaper-NEW -> any upload will work
watchPaper-KEYWORD -> any update to reverse index of the keyword str

searchScholar is independent from the uploaded papers but returned metadata can be transfered to one of the paper in your library.

also check tfidf for inverted index if you are interested in information retrieval.
